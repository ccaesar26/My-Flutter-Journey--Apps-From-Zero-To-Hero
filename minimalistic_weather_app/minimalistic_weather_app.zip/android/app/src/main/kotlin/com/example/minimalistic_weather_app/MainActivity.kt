package com.example.minimalistic_weather_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
